package com.shpp.p2p.cs.phlynskyi.assignment12;

import javax.imageio.ImageIO;
import java.awt.*;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;


public class Assignment12Part1 {

    private static final int BLACK_PIXEL = 0;
    private static final int WHITE_PIXEL = 1;

    // constant for control of big object size
    // adjust value, to count smaller objects also
    private static final double SIZE_COEFFICIENT = 5000;

    // coordinates of neighbor pixel
    private static final int[] NEIGHBOR_X = {0, 1, 0, -1};
    private static final int[] NEIGHBOR_Y = {-1, 0, 1, 0};


    private boolean[][] visitedPixels;

    public static void main(String[] args) {
        // This new thread made to resolve stackoverflowerror
        new Thread(null, () -> {
            try {
                String imageName;
                if (args.length > 0) {
                    imageName = args[0];
                } else {
                    imageName = "test.jpg";
                }

                // Load image and process it
                Assignment12Part1 app = new Assignment12Part1();

                BufferedImage image = app.loadImage(imageName);
                int silhouetteCount = app.findSilhouettes(image);

                System.out.println("Number of silhouettes: " + silhouetteCount);
            } catch (IOException e) {
                System.err.println("Error processing image: " + e.getMessage());
            }
        }, "1", 512 * 1024 * 1024).start();
    }

    private BufferedImage loadImage(String imagePath) {
        BufferedImage img;

        try {
            img = ImageIO.read(new File(imagePath));
        } catch (IOException e) {
            throw new RuntimeException("Failed to load image file.");
        }
        return img;
    }

    /**
     * Converts given image to a black-white pixel arrau.
     *
     * @param image image to convert
     * @return array of integers representing pixel array
     */
    public int[][] getPixelsFromImage(BufferedImage image) {

        int height = image.getHeight();
        int width = image.getWidth();
        int[][] pixels = new int[height][width];

        for (int y = 0; y < height; y++) {
            for (int x = 0; x < width; x++) {
                pixels[y][x] = image.getRGB(x, y);
            }
        }

        return convertToBlackAndWhite(convertToMidValue(pixels));
    }

    /**
     * Converts a pixel grid to middle value.
     *
     * @param pixels array of integers representing pixel grid
     * @return new version of the input pixel grid
     */
    private int[][] convertToMidValue(int[][] pixels) {
        int height = pixels.length;
        int width = pixels[0].length;

        for (int y = 0; y < height; y++) {
            for (int x = 0; x < width; x++) {
                Color color = new Color(pixels[y][x]);
                int grayValue = (color.getRed() + color.getGreen() + color.getBlue()) / 3;
                pixels[y][x] = new Color(grayValue, grayValue, grayValue).getRGB();
            }
        }
        return pixels;
    }

    /**
     * Converts a middle-value pixel grid to black-white based on an average threshold.
     * If the number of black pixels exceeds the number of white pixels, the black-and-white colors are inverted.
     *
     * @param pixels array of integers representing the grayscale pixel grid
     * @return the black-and-white version of the input pixel grid
     */
    private int[][] convertToBlackAndWhite(int[][] pixels) {
        int averageValue = calculateAverageValue(pixels);
        int blackCount = 0, whiteCount = 0;

        for (int y = 0; y < pixels.length; y++) {
            for (int x = 0; x < pixels[0].length; x++) {
                if (pixels[y][x] < averageValue) {
                    pixels[y][x] = BLACK_PIXEL;
                    blackCount++;
                } else {
                    pixels[y][x] = WHITE_PIXEL;
                    whiteCount++;
                }
            }
        }

        if (blackCount > whiteCount) {
            // Invert all black and white pixels
            for (int y = 0; y < pixels.length; y++) {
                for (int x = 0; x < pixels[0].length; x++) {
                    pixels[y][x] = (pixels[y][x] == BLACK_PIXEL) ? WHITE_PIXEL : BLACK_PIXEL;
                }
            }
        }

        return pixels;
    }

    /**
     * Calculates the average pixel value in the pixel grid.
     *
     * @param pixels array of integers representing the pixel grid
     * @return the average value of all pixels in the grid
     */
    private int calculateAverageValue(int[][] pixels) {
        int min = pixels[0][0], max = pixels[0][0];

        for (int[] row : pixels) {
            for (int pixel : row) {
                if (pixel > max) {
                    max = pixel;
                }
                if (pixel < min) {
                    min = pixel;
                }
            }
        }

        return (max + min) / 2;
    }

    /**
     * Finds the number of silhouettes in image by detecting big groups of black pixels.
     *
     * @param image image file to analyze
     * @return the number of detected silhouettes
     * @throws IOException if an error occurs while loading the image file
     */
    public int findSilhouettes(BufferedImage image) throws IOException {
        int[][] pixels = getPixelsFromImage(image);
        visitedPixels = new boolean[pixels.length][pixels[0].length];
        int silhouetteNumber = 0;
        double imageArea = pixels.length * pixels[0].length;
        double bigObjectSize = imageArea / SIZE_COEFFICIENT;

        for (int y = 0; y < pixels.length; y++) {
            for (int x = 0; x < pixels[0].length; x++) {
                if (pixels[y][x] == BLACK_PIXEL && !visitedPixels[y][x]) {
                    int currentSize = 0;
                    currentSize = recursiveSearch(pixels, y, x, currentSize);
                    if (currentSize > bigObjectSize) {
                        silhouetteNumber++;
                    }
                }
            }
        }

        return silhouetteNumber;
    }

    /**
     * Recursively searches for connected black pixels in the pixel grid and counts the size of the silhouette.
     *
     * @param pixelGrid array of integers representing the black-and-white pixel grid
     * @param y the current y-coordinate of pixel
     * @param x the current x-coordinate of pixel
     * @param silhouetteSize the current size of the silhouette being counted
     * @return the updated size of the silhouette
     */
    private int recursiveSearch(int[][] pixelGrid, int y, int x, int silhouetteSize) {
        if (y >= 0 && y < pixelGrid.length && x >= 0 && x < pixelGrid[0].length) {
            if (pixelGrid[y][x] == BLACK_PIXEL && !visitedPixels[y][x]) {
                visitedPixels[y][x] = true;
                silhouetteSize++;
                for (int k = 0; k < NEIGHBOR_X.length; k++) {
                    silhouetteSize = recursiveSearch(pixelGrid, y + NEIGHBOR_Y[k], x + NEIGHBOR_X[k], silhouetteSize);
                }
            }
        }
        return silhouetteSize;
    }
}
